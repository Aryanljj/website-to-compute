# How to Deploy on Netlify

1. Go to https://app.netlify.com/ and sign up with Google/GitHub.
2. After login, go to your Netlify dashboard.
3. Click on "Add new site" → "Deploy manually".
4. Drag & Drop this **aryan_final_website.zip** file into the upload box (or click 'browse to upload').
5. Netlify will process and give you a public link like:
   https://yourname.netlify.app
6. Share that link with anyone, it will stay online!

🔥 Enjoy your new website Aryan!
